

class ConnectionDetails {
    public:
    DataCache* dataCache;
    string clientIP;
    int connectionFD;
    int connectionID;
};